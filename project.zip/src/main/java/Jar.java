import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;


public class Jar {
    
    private String mItemName;
    private int mItemMaxNumber;
    private int someNumber;
   

    public Jar(String name, int maxNumber) {
        mItemName = name;
        mItemMaxNumber = maxNumber;
     
        
    }

    public String getmName() {
        return mItemName;
    }

    public void setmName(String name) {
        mItemName = name;
    }

    public int getmMaxNumber() {
        return mItemMaxNumber;
    }
    

    
    public void setmMaxNumber(int maxNumber) {
        mItemMaxNumber = maxNumber;
    }
    
    public int fill(int mItemMaxNumber) {
        
    Random random = new Random();
    someNumber = random.nextInt(mItemMaxNumber+1);
   
    
    return someNumber;
    }


    
    
}
