import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;


public class Prompter {
   private BufferedReader mReader;  
   private String mItemName;
   private int mItemMaxNumber;
   private int someNumber;
  
   
    public Prompter() {
        mReader = new BufferedReader(new InputStreamReader(System.in));
      
    }
    
    
    public void promptAdmin() throws IOException {
        
    System.out.println("ADMINISTRATOR SETUP:");
    System.out.println("--------------------");
    
    System.out.println("Name of the item in a jar: ");
    mItemName=mReader.readLine();
    
    System.out.println("Maximum number of " +mItemName+ " in a jar: ");
    String mItemMaxNumberString=mReader.readLine();
    mItemMaxNumber=Integer.parseInt(mItemMaxNumberString);
    
    
    }
        
    public void promptUser() throws IOException {
        
    System.out.printf("PLAYER:%n");
    System.out.printf("--------------------%n");
    System.out.printf("Your goal is to guess how many %s are in the jar.%n",mItemName);
    System.out.printf("Your guess should be between 1 and %d: %n", mItemMaxNumber);
    System.out.printf("Ready? (press enter to start guessing)%n");
   
    
    
    }     
    
    public void play() throws IOException{
        
    boolean guessed=false;
    int count=0;
    Jar jar= new Jar("candies", 50);
    someNumber=jar.fill(mItemMaxNumber);
     
    while(guessed==false){

      
       System.out.printf("Guess:%n");
       String numberToGuessString=mReader.readLine(); 
       int number=Integer.parseInt(numberToGuessString);  
       //System.out.print("Broj sa konzole je..."+ number);
       
       if (number>mItemMaxNumber) {
           System.out.printf("Your guess must be less than %d.%n",mItemMaxNumber );
           
       }
       
       if (number==someNumber) {
           guessed=true;
           count++;
        System.out.printf("Congratulations-you guessed that there are %d %s.%n", someNumber,mItemName);  
        System.out.printf("It took you %d guess(es) to get it right.%n", count);  
       }
        
       else if (number>someNumber && number<mItemMaxNumber) {
           System.out.printf("Your guess is too high.%n");
           count++;
       }
       
       else if (number<someNumber) {
           System.out.printf("Your guess is too low.%n");
           count++;
       }
       
   
     }       

        
   
    
}
    
}